print("What is your name?")
name = input()
print("hello,", name)
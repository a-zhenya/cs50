#include <stdio.h>
#include <string.h>
//#include "bmp.h"
#include "helpers.h"

int main() {
    RGBTRIPLE image[3][3];
    memset( image, 0, sizeof(image) );

    image[0][0].rgbtBlue =  25;    image[0][1].rgbtBlue =  30;    image[0][2].rgbtBlue =  80;
    image[1][0].rgbtBlue =  90;    image[1][1].rgbtBlue = 100;    image[1][2].rgbtBlue = 90;
    image[2][0].rgbtBlue =  40;    image[2][1].rgbtBlue = 30;    image[2][2].rgbtBlue = 10;

    edges(3, 3, image);
    for (int k = 0; k < 3; k ++) {
        for (int l = 0; l < 3; l++) {
            printf(" (%i,%i,%i)", (int)image[k][l].rgbtBlue, (int)image[k][l].rgbtRed, (int)image[k][l].rgbtGreen);
        }
        printf("\n");
    }
    return 0;
}